from flask import Flask, request, render_template, jsonify
from groq import Groq
import json

client = Groq(api_key='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')

# prompt_templates = {
#     "WBS": "Create a detailed Work Breakdown Structure (WBS) for a project focused on {project_description}. Include all major deliverables, sub-tasks, and the relationships between them.",
#     "SRS": "Generate a Software Requirements Specification (SRS) for a project focused on {project_description}. Include sections for functional requirements, non-functional requirements, system features, external interface requirements, and user classes.",
#     "Epics_and_User_Stories": "Develop a list of epics and detailed user stories for a project aimed at {project_description}. Each epic should cover a significant functionality area, and user stories should describe specific interactions a user might have with the system.",
#     "NFRs": "List the non-functional requirements for a project with the objective of {project_description}. Include requirements related to performance, usability, reliability, security, and scalability.",
# }

# Load prompt templates from JSON file
with open("prompts.json", "r") as file:
    prompt_templates = json.load(file)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_documentation():
    data = request.get_json()  # Retrieve JSON data
    user_input = data.get('requirements')  # Get 'requirements' from JSON

    if not user_input:
        return jsonify({"error": "No requirements provided"}), 400

    documentation = {}

    for doc_type, template in prompt_templates.items():
        prompt = template.format(project_description=user_input)
        response = generate_requirements(prompt)
        documentation[doc_type] = response

    return jsonify(documentation)


def generate_requirements(prompt):
    response = client.chat.completions.create(
        model="mixtral-8x7b-32768",
        messages = [
            {"role":"system","content":"you are a helpful assistant."},
            {"role":"user","content": prompt}]
    )
    return response.choices[0].message.content

if __name__ == '__main__':
    app.run(debug=True)
