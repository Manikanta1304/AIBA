from flask import Flask, request, render_template, jsonify
from groq import Groq
import json
import requests
import base64
import os

client = Groq(api_key='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')

# Load prompt templates from JSON file
with open("prompts.json", "r") as file:
    prompt_templates = json.load(file)

# Cleaning up the LLM output
def format_mermaid_syntax(output):
    # Remove the backticks and any prefix or suffix
    cleaned_output = output.strip()
    
    # Split by space to find connections and format them line-by-line
    components = cleaned_output.split(" ")
    
    # Join each component on a new line for readability
    formatted_output = "\n    ".join(components)
    
    # Add "flowchart TD" directive at the beginning
    final_syntax = f"{formatted_output}"
    return final_syntax

def generate_mermaid_diagram(mermaid_syntax):
    # Base64 encode the Mermaid syntax
    encoded_syntax = base64.urlsafe_b64encode(mermaid_syntax.encode("utf-8")).decode("utf-8")
    url = f"https://mermaid.ink/img/{encoded_syntax}"

    response = requests.get(url)

    # Ensure the 'static' directory exists
    if not os.path.exists('static'):
        os.makedirs('static')

    if response.status_code == 200:
        # Save the image in the 'static' directory with a unique name
        image_filename = "diagram.png"
        image_path = os.path.join('static', image_filename)

        with open(image_path, "wb") as file:
            file.write(response.content)

        # Return the relative URL for the image
        return f'/static/{image_filename}'
    else:
        print("Failed to generate image:", response.status_code, response.text)
        return None
    

    # # Download the image
    # response = requests.get(url)

    # # Save the image if the request was successful
    # if response.status_code == 200:
    #     with open("diagram.png", "wb") as file:
    #         file.write(response.content)
    #     print("Image saved as diagram.png")
    # else:
    #     print("Failed to generate image:", response.status_code, response.text)


app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_documentation():
    data = request.get_json()  # Retrieve JSON data
    user_input = data.get('requirements')  # Get 'requirements' from JSON

    if not user_input:
        return jsonify({"error": "No requirements provided"}), 400

    documentation = {}

    for doc_type, template in prompt_templates.items():
        prompt = template.format(project_description=user_input)
        response = generate_requirements(prompt)
        if doc_type == 'Mermaid_Diagram':
            response = format_mermaid_syntax(response)
        documentation[doc_type] = response

    print(documentation['Mermaid_Diagram'])

    # Generate the diagram and get the URL
    mermaid_diagram_url = generate_mermaid_diagram(documentation['Mermaid_Diagram'])

    # Include the diagram URL in the documentation output
    documentation['Mermaid_Diagram_URL'] = mermaid_diagram_url
    return jsonify(documentation)


def generate_requirements(prompt):
    response = client.chat.completions.create(
        model="mixtral-8x7b-32768",
        messages = [
            {"role":"system","content":"you are a helpful assistant."},
            {"role":"user","content": prompt}]
    )
    return response.choices[0].message.content

if __name__ == '__main__':
    app.run(debug=True)
