from flask import Flask, request, render_template, jsonify
from groq import Groq
import json
import requests
import base64
import os
import re
from flask import send_file
from docx import Document
from io import BytesIO

client = Groq(api_key='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')

# Load prompt templates from JSON file
with open("prompts.json", "r") as file:
    prompt_templates = json.load(file)

def format_mermaid_syntax(output):
    """
    Refines and extracts the exact Mermaid syntax from the LLM output.
    
    Args:
        output (str): The raw output from the LLM.
    
    Returns:
        str: Cleaned and properly formatted Mermaid syntax.
    """
    # Step 1: Remove unnecessary backticks and trim whitespace
    cleaned_output = output.strip().replace("```", "")
    
    # Step 2: Extract Mermaid syntax using regex to match diagram types
    mermaid_match = re.search(r"(graph TD|graph LR|sequenceDiagram|classDiagram|stateDiagram-v2|flowchart TD).*", cleaned_output, re.DOTALL)
    
    if not mermaid_match:
        raise ValueError("No valid Mermaid syntax found in the output.")
    
    # Step 3: Get the matched Mermaid syntax
    mermaid_syntax = mermaid_match.group(0).strip()
    
    # Step 4: Remove unnecessary line breaks or extra spaces for better formatting
    mermaid_syntax = "\n".join([line.strip() for line in mermaid_syntax.splitlines() if line.strip()])
    
    return mermaid_syntax


def generate_mermaid_diagram(mermaid_syntax):
    # Base64 encode the Mermaid syntax
    encoded_syntax = base64.urlsafe_b64encode(mermaid_syntax.encode("utf-8")).decode("utf-8")
    url = f"https://mermaid.ink/img/{encoded_syntax}"

    response = requests.get(url)

    # Ensure the 'static' directory exists
    if not os.path.exists('static'):
        os.makedirs('static')

    if response.status_code == 200:
        # Save the image in the 'static' directory with a unique name
        image_filename = "diagram.png"
        image_path = os.path.join('static', image_filename)

        with open(image_path, "wb") as file:
            file.write(response.content)

        # Return the relative URL for the image
        return f'/static/{image_filename}'
    else:
        print("Failed to generate image:", response.status_code, response.text)
        return None
    

    # # Download the image
    # response = requests.get(url)

    # # Save the image if the request was successful
    # if response.status_code == 200:
    #     with open("diagram.png", "wb") as file:
    #         file.write(response.content)
    #     print("Image saved as diagram.png")
    # else:
    #     print("Failed to generate image:", response.status_code, response.text)



app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_documentation():
    data = request.get_json()  # Retrieve JSON data
    user_input = data.get('requirements')  # Get 'requirements' from JSON

    if not user_input:
        return jsonify({"error": "No requirements provided"}), 400

    documentation = {}

    for doc_type, template in prompt_templates.items():
        prompt = template.format(project_description=user_input)
        response = generate_requirements(prompt)
        if doc_type == 'Mermaid_Diagram':
            response = format_mermaid_syntax(response)
        documentation[doc_type] = response

    print(documentation['Mermaid_Diagram'])

    # Generate the diagram and get the URL
    mermaid_diagram_url = generate_mermaid_diagram(documentation['Mermaid_Diagram'])

    # Include the diagram URL in the documentation output
    documentation['Mermaid_Diagram_URL'] = mermaid_diagram_url
    return jsonify(documentation)


def generate_requirements(prompt):
    response = client.chat.completions.create(
        model="mixtral-8x7b-32768",
        messages = [
            {"role":"system","content":"you are a helpful assistant."},
            {"role":"user","content": prompt}]
    )
    return response.choices[0].message.content


from flask import request, url_for  # Ensure these imports are present
from docx.shared import Inches

@app.route('/download', methods=['POST'])
def download_word_file():
    data = request.get_json()  # Retrieve JSON data with documentation content
    documentation = data.get('documentation')

    if not documentation:
        return jsonify({"error": "No documentation content provided"}), 400

    # Create a Word document
    doc = Document()

    for doc_type, content in documentation.items():
        doc.add_heading(doc_type, level=1)  # Add section title

        if doc_type == 'Mermaid_Diagram_URL':
            # Convert relative URL to absolute URL
            absolute_url = request.host_url.rstrip('/') + content  # Ensures no trailing slash duplication
            
            # Download and insert the Mermaid image
            response = requests.get(absolute_url)
            if response.status_code == 200:
                image_stream = BytesIO(response.content)
                doc.add_picture(image_stream, width=Inches(3))  # Adjust width as needed
            else:
                doc.add_paragraph("Failed to load Mermaid diagram image.")
        else:
            doc.add_paragraph(content)  # Add content as a paragraph

    # Save the Word document to an in-memory buffer
    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)

    # Send the Word file as a response
    return send_file(
        buffer,
        as_attachment=True,
        download_name="documentation.docx",
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )



if __name__ == '__main__':
    app.run(debug=True)
